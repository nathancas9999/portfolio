import java.util.GregorianCalendar;

public class dvd {
    private String titre;
    private char couleur;
    private GregorianCalendar dateSortie;
    private GregorianCalendar dateVisionnage;

    public dvd() {
    }

    public dvd(String titre, char couleur, GregorianCalendar dateSortie, GregorianCalendar dateVisionnage) {
        this.titre = titre;
        this.setCouleur(couleur);
        this.setDateSortie(dateSortie);
        this.dateVisionnage = dateVisionnage;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public char getCouleur() {
        return couleur;
    }

    public void setCouleur(char couleur) {
        if (couleur == 'V' || couleur == 'R') {
            this.couleur = couleur;
        } else {
            throw new IllegalArgumentException("Couleur invalide. Veuillez utiliser 'V' pour Vert ou 'R' pour Rouge.");
        }
    }

    public GregorianCalendar getDateSortie() {
        return dateSortie;
    }

    public void setDateSortie(GregorianCalendar dateSortie) {
        GregorianCalendar today = new GregorianCalendar();
        if (dateSortie.after(today)) {
            throw new IllegalArgumentException("Date de sortie invalide. La date ne peut pas être supérieure à la date d'aujourd'hui.");
        }
        this.dateSortie = dateSortie;
    }

    public GregorianCalendar getDateVisionnage() {
        return dateVisionnage;
    }

    public void setDateVisionnage(GregorianCalendar dateVisionnage) {
        this.dateVisionnage = dateVisionnage;
    }

    public double prixDVD() {
        switch (couleur) {
            case 'R':
                return 3.0;
            case 'V':
                return 2.0;
            default:
                return 0.0;
        }
    }

    public boolean isNouveaute() {
        GregorianCalendar today = new GregorianCalendar();
        GregorianCalendar threeMonthsAgo = (GregorianCalendar) today.clone();
        threeMonthsAgo.add(GregorianCalendar.MONTH, -3);
        return dateSortie.after(threeMonthsAgo);
    }
}
