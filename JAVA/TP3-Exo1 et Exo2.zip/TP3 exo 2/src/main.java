import java.util.GregorianCalendar;
import java.util.Scanner;

public class main {
    public static void main(final String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Entrez le titre du DVD :");
        String titre = scanner.nextLine();

        System.out.println("Entrez la couleur du DVD (V pour Vert, R pour Rouge) :");
        char couleur = scanner.next().charAt(0);
        while (couleur != 'V' && couleur != 'R') {
            System.out.println("Couleur invalide. Veuillez entrer 'V' pour Vert ou 'R' pour Rouge :");
            couleur = scanner.next().charAt(0);
        }

        GregorianCalendar today = new GregorianCalendar();

        System.out.println("Entrez l'année de sortie (format YYYY) :");
        int annee = scanner.nextInt();
        while (annee > today.get(GregorianCalendar.YEAR)) {
            System.out.println("Année invalide. Veuillez entrer une année valide :");
            annee = scanner.nextInt();
        }

        System.out.println("Entrez le mois de sortie (format MM) :");
        int mois = scanner.nextInt() - 1;
        while (mois < 0 || mois > 11) {
            System.out.println("Mois invalide. Veuillez entrer un mois valide (1-12) :");
            mois = scanner.nextInt() - 1;
        }

        System.out.println("Entrez le jour de sortie (format DD) :");
        int jour = scanner.nextInt();
        while (jour < 1 || jour > 31) {
            System.out.println("Jour invalide. Veuillez entrer un jour valide (1-31) :");
            jour = scanner.nextInt();
        }

        GregorianCalendar dateSortie = new GregorianCalendar(annee, mois, jour);
        while (dateSortie.after(today)) {
            System.out.println("Date de sortie invalide. La date ne peut pas être supérieure à la date d'aujourd'hui. Veuillez réessayer :");
            System.out.println("Entrez l'année de sortie (format YYYY) :");
            annee = scanner.nextInt();
            System.out.println("Entrez le mois de sortie (format MM) :");
            mois = scanner.nextInt() - 1;
            System.out.println("Entrez le jour de sortie (format DD) :");
            jour = scanner.nextInt();
            dateSortie = new GregorianCalendar(annee, mois, jour);
        }

        dvd monDVD = new dvd(titre, couleur, dateSortie, null);

        System.out.println("Entrez le nouveau titre du DVD :");
        scanner.nextLine();
        String nouveauTitre = scanner.nextLine();
        monDVD.setTitre(nouveauTitre);

        System.out.println("Prix du DVD : " + monDVD.prixDVD());

        if (monDVD.isNouveaute()) {
            System.out.println("C'est une nouveauté.");
        } else {
            System.out.println("Ce n'est pas une nouveauté.");
        }

        System.out.printf("Date de sortie du film : %d-%d-%d\n", dateSortie.get(GregorianCalendar.YEAR), dateSortie.get(GregorianCalendar.MONTH) + 1, dateSortie.get(GregorianCalendar.DAY_OF_MONTH));

        scanner.close();
    }
}
